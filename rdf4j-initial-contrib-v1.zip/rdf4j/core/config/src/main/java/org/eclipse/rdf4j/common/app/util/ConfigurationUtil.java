/*******************************************************************************
 * Copyright (c) 2015, Eclipse Foundation, Inc. and its licensors.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * - Neither the name of the Eclipse Foundation, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *******************************************************************************/
package org.eclipse.rdf4j.common.app.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.eclipse.rdf4j.common.app.config.Configuration;
import org.eclipse.rdf4j.common.io.IOUtil;
import org.eclipse.rdf4j.common.io.ResourceUtil;

public class ConfigurationUtil {

	/**
	 * Load configuration settings from the specified file.
	 * 
	 * @param file
	 *        the file to load from
	 * @return the contents of the file as a String, or null if the file did not
	 *         exist
	 * @throws IOException
	 *         if the contents of the file could not be read due to an I/O
	 *         problem
	 */
	public static String loadConfigurationContents(File file)
		throws IOException
	{
		String result = null;
		if (file.exists()) {
			result = IOUtil.readString(file);
		}
		return result;
	}

	/**
	 * Load configuration settings from a resource on the classpath.
	 * 
	 * @param resourceName
	 *        the name of the resource
	 * @return the contents of the resources as a String, or null if the
	 *         resource, nor its default, could be found
	 * @throws IOException
	 *         if the resource could not be read due to an I/O problem
	 */
	public static String loadConfigurationContents(String resourceName)
		throws IOException
	{
		String result = null;
		InputStream in = ResourceUtil.getInputStream(getResourceName(resourceName));
		if (in == null) {
			in = ResourceUtil.getInputStream(getDefaultResourceName(resourceName));
		}
		if (in != null) {
			result = IOUtil.readString(in);
		}
		return result;
	}

	/**
	 * Load configuration properties from the specified file.
	 * 
	 * @param file
	 *        the file to load from
	 * @return the contents of the file as Properties, or null if the file did
	 *         not exist
	 * @throws IOException
	 *         if the contents of the file could not be read due to an I/O
	 *         problem
	 */
	public static Properties loadConfigurationProperties(File file, Properties defaults)
		throws IOException
	{
		Properties result = null;
		if (file.exists()) {
			result = IOUtil.readProperties(file, defaults);
		}
		else {
			result = new Properties(defaults);
		}
		return result;
	}

	/**
	 * Load configuration properties from a resource on the classpath.
	 * 
	 * @param resourceName
	 *        the name of the resource
	 * @return the contents of the resource as Properties
	 * @throws IOException
	 *         if the resource could not be read due to an I/O problem
	 */
	public static Properties loadConfigurationProperties(String resourceName, Properties defaults)
		throws IOException
	{
		Properties result = null;

		String defaultResourceName = getDefaultResourceName(resourceName);

		Properties defaultResult = null;
		InputStream in = ResourceUtil.getInputStream(defaultResourceName);
		if (in != null) {
			defaultResult = IOUtil.readProperties(in, defaults);
		}
		else {
			defaultResult = new Properties(defaults);
		}

		// load application-specific overrides
		in = ResourceUtil.getInputStream(getResourceName(resourceName));
		if (in != null) {
			result = IOUtil.readProperties(in, defaultResult);
		}
		else {
			result = new Properties(defaultResult);
		}

		return result;
	}

	private static String getResourceName(String resourceName) {
		StringBuilder result = new StringBuilder(Configuration.RESOURCES_LOCATION);
		if (resourceName.startsWith("/")) {
			resourceName = resourceName.substring(1);
		}
		result.append(resourceName);
		return result.toString();
	}

	private static String getDefaultResourceName(String resourceName) {
		StringBuilder result = new StringBuilder(Configuration.DEFAULT_RESOURCES_LOCATION);
		if (resourceName.startsWith("/")) {
			resourceName = resourceName.substring(1);
		}
		result.append(resourceName);
		return result.toString();
	}

	/**
	 * Save configuration settings to a file.
	 * 
	 * @param contents
	 *        the configuration settings
	 * @param file
	 *        the file to write to
	 * @throws IOException
	 *         if the settings could not be saved because of an I/O problem
	 */
	public static void saveConfigurationContents(String contents, File file)
		throws IOException
	{
		if (file.getParentFile().mkdirs() || file.getParentFile().canWrite()) {
			IOUtil.writeString(contents, file);
		}
	}

	/**
	 * Save configuration properties to a file.
	 * 
	 * @param props
	 *        the configuration properties
	 * @param file
	 *        the file to write to
	 * @throws IOException
	 *         if the settings could not be saved because of an I/O problem
	 */
	public static void saveConfigurationProperties(Properties props, File file, boolean includeDefaults)
		throws IOException
	{
		if (file.getParentFile().mkdirs() || file.getParentFile().canWrite()) {
			IOUtil.writeProperties(props, file, includeDefaults);
		}
	}
}
